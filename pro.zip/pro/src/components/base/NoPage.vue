<template>
	<div class="flex">
		<img src="../../../static/img/github.png" />
		<p>暂无数据，请前往添加。</p>
	</div>
</template>

<style lang="less" scoped>
	div {
		flex-direction: column;
		align-items: center;
		justify-content: center;
		font-size: .28rem;
	}

	img {
		text-align: center;
		margin: .3rem 0;
		width: 2rem;
		height: 2rem;
	}

	p {
		text-align: center;
	}
</style>

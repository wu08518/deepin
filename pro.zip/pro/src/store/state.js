const state = {
	address:['广东省深圳市 南山区'], //默认地址
	carts:[{"CategoryId":"1","GoodsName":"默认商品","GoodsPrice":9,"GoodsNum":1,"GoodsImage":"./static/img/github.png"}], //购物车默认商品
	comname:'index', //默认组件名字
	ordercur:1       //默认订单下标
}
export default state
 